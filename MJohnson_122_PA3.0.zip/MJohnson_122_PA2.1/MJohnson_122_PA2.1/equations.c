#include "Header.h"

/*************************************************************
* Function: void display_menu(void)
* Date Last Modified:      9:12:16
* Description:     This program prints the options that the user can enter.
* Returns:				void
*************************************************************/
void display_menu(void)
{
	printf("---Music Library Menu---\nSelect an option by typing the corresponding number.\n");
	printf("1. Load Records.\n");
	printf("2. Store Records.\n");
	printf("3. Display Records.\n");
	printf("4. Insert Records.\n");
	printf("5. Delete Records.\n");
	printf("6. Edit Records.\n");
	printf("7. Sort Records.\n");
	printf("8. Rate Records.\n");
	printf("9. Exit Library.\n");
}

/*************************************************************
* Function: int get_option(void)
* Date Last Modified:       9:12:16
* Description:     This program recieves the option form the user.
* Returns:				option
*************************************************************/
int get_option(void)
{
	int option = 0;

	scanf("%d", &option);//get user choice
	return option;
}

/*************************************************************
* Function: int is_valid(int option)
* Date Last Modified:      9:12:16
* Description:     This program check that the entered option is a 1-9.
* Returns:				status
*************************************************************/
int is_valid(int option)
{
	int status = 1;


	if ((option < 1) || (option > 9))
	{
		status = 0; //invalid
		printf("Please enter a number between 1 and 9 (inclusive)\n");//reprompt
	}
	return status;
}

/*************************************************************
* Function: int is_display_valid(int option)
* Date Last Modified:      9:12:16
* Description:     This program check that the entered option is a 1-2.
* Returns:				status
*************************************************************/
int is_display_valid(int option)
{
	int status = 1;

	if ((option < 0) || (option > 3))
	{
		status = 0; //invalid
		printf("Please enter either a 1 or a 0.\n"); //reprompt
	}
	return status;
}

/*************************************************************
* Function: int run_menu(void)
* Date Last Modified:      9:12:16
* Description:     This program runs the first three created functions
in an effort to reduce repetition.
* Returns:				option
*************************************************************/
int run_menu(void)
{
	int status = 0, option = 0;
	do
	{
		display_menu(); // display menu
		option = get_option(); // get option from user
		status = is_valid(option); // check the validity of the option
	} while (status == 0); // status != 1
	return option;
}

/*************************************************************
* Function: int determine_operation(int option, int exit_value, Node **pList)
* Date Last Modified:      9:14:16
* Description:     This program runs a switch statment that either loads, stores, displays, inserts, deletes, edits, rates, or exits.
* Pre: run_menu must have been ran
* Returns:				exit_value
*************************************************************/
int determine_operation(int option, Node**pList)
{
	int option_disp = 0, status = 0, sort_option = 0, exit_value = 0;
	char desired_artist[50] = { "\0" }, desired_song[50] = { "\0" }, delete_song[50] = { "\0" }, desired_artist_edit[50] = { "\0" };

	system("cls");
	switch (option)
	{
	case LOAD: 
		load_by_reading(pList);
		break;
	case STORE:
		store_by_writing(*pList);
		break;
	case DISPLAY:
		system("cls");
		while (status != 1)
		{
			printf("What would you like to display?\nEnter a 1 to print all records, Enter a 2 to print records by artist.\n");
			option_disp = get_option(); //re-run menu
			status = is_display_valid(option_disp);  //re-run menu
		}
			if (option_disp == 1)
			{
				system("cls");
				printf("Printing All Records...\n");
				display_all_records(*pList);
				printf("\n\n");
			}
			else
			{
				system("cls");
				printf("What artist would you like to print? (Case sensitive and white space sensitive)\n");
				printf("EXAMPLE: ' Drake '\n");
				printf("EXAMPLE: ' \"Swift, Taylor\" '\n");
				gets(desired_artist);
				gets(desired_artist);//get user choice
				printf("Printing All Records That Match Exactly '%s'...\n", desired_artist);
				display_by_artist(*pList, desired_artist);
			}
		break;
	case INSERT:
		insert_new_song(pList);
		break;
	case DELETE:
		system("cls");
		printf("What song would you like to delete? (Case sensitive and white space sensitive)\n");
		printf("EXAMPLE: ' Shake it Off '\n");
		gets(delete_song);
		gets(delete_song);//get user choice
		printf("Deleting All Records That Match Exactly '%s'...\n", delete_song);
		delete_by_song(pList, delete_song);
		break;
	case EDIT:
		printf("What Artist would you like to edit? (Case sensitive and white space sensitive)\n");
		printf("EXAMPLE: ' Drake '\n");
		printf("EXAMPLE: ' \"Swift, Taylor\" '\n");
		gets(desired_artist_edit);
		gets(desired_artist_edit);//get user choice
		edit_by_artist(pList, desired_artist_edit);
		break;
	case SORT:
		printf("Select the sorting method you wish to organize your music to.\n");
		printf("(1) Sort Alphabetically from A-Z by Artist.\n");
		printf("(2) Sort Alphabetically from A-Z by Album Title.\n");
		printf("(3) Sort Based on Rating from 5-1.\n");
		printf("(4) Sort based on Play Count from Highest to Lowest.\n");
		scanf("%d", &sort_option);//get user choice
		sort_by_bubble(pList, sort_option);
		break;
	case RATE:
		system("cls");
		printf("What song would you like to rate? (Case sensitive and white space sensitive)\n");
		printf("EXAMPLE: ' Shake it Off '\n");
		gets(desired_song);
		gets(desired_song); //get user choice
		rate_by_song(pList, desired_song);
		break;
	case EXIT: 
		printf("Come back to your music soon!\n");
		store_by_writing(*pList);
		exit_value = 1; //user chose to exit, program flag changes
		break;
	default:
		break;
	}
	return exit_value;
}

/*************************************************************
* Function: Node * makeNode(Record newData)
* Date Last Modified:      9:12:16
* Description:     This program allocates space on the heap for a node of size Record. This is a doubly linked node.
* Pre: struct Record must exist
* Returns:				pMem
*************************************************************/
Node * makeNode(Record newData)//makenode allocates space on the heap
{
	Node * pMem = NULL;
	pMem = (Node *)malloc(sizeof(Node));//allocating space for a node

	if (pMem != NULL)//check allocated space before accessing fields in nodes
	{
		(*pMem).pNext = NULL;
		pMem->pPrev = NULL; //added for a doubly linked list
							//strcpy(pMem->data.name, newData.name); //long way of doing what is done below
		pMem->data = newData; //copied the bytes of a struct into newData
	}
	return pMem;
}

/*************************************************************
* Function: int InsertFront(Node **pList, Record newData)
* Date Last Modified:      9:12:16
* Description:     This program inserts a doubly linked node to the front of a linked list of size records.
* Pre: makeNode must exist
* Returns:				success
*************************************************************/
int InsertFront(Node **pList, Record newData)
{
	Node * pMem = NULL;
	int success = 0; //failed at inserting (0 means false)

	pMem = makeNode(newData);
	if (pMem != NULL) //we allocated space on the heap for our node
	{
		success = 1;
		if (*pList == NULL)//list is empty and this is our first node
		{
			*pList = pMem;
		}
		else //list is not empty
		{
			//1. set the next pointer of allocated Node to the front of list
			pMem->pNext = *pList;
			(*pList)->pPrev = pMem;
			*pList = pMem;
		}
	}
	return success;
}

/*************************************************************
* Function: int load_by_reading(Node **pList)
* Date Last Modified:      9:14:16
* Description:     This program reads from a file the artist, song title, duration, rating, playcount, and genre of a record.
* Colloaborator(s): Josh Mandoli
* Pre: makeNode must exist
* Returns:				success
*************************************************************/
int load_by_reading(Node **pList)
{
	char line_one[200] = "", *token = NULL;
	int success = 0;
	int i = 0;
	Record r;
	FILE *infile = fopen("music.csv", "r");

	if (infile != NULL)//file opened succesfully
	{
		while (i<9)
		{
			fgets(line_one, 100, infile);
			if (line_one[0] == '\"') // this compares to see if artist name consists of last and first
			{
				token = strtok(line_one, ",");//the comma is the delimiter
				strcpy(r.Artist, token);//Overwrite
				token = ","; //add comma 
				token = strcat(r.Artist, token);//Overwrite
				token = strtok(NULL, ",");				//NULL allows us to continue reading from where we left off
				token = strcat(r.Artist, token);//Overwrite
				token = NULL; //reset
			}
			else
			{
				token = strtok(line_one, ",");//the comma is the delimiter
				strcpy(r.Artist, token);//Overwrite
			}
			token = strtok(NULL, ",");//the comma is the delimiter
			strcpy(r.Album, token);
			token = strtok(NULL, ",");					//NULL allows us to continue reading from where we left off
			strcpy(r.Song, token);					//appends first to last, //Overwrite
			token = strtok(NULL, ",");					//NULL allows us to continue reading from where we left off
			strcpy(r.Genre, token);		//Overwrite

			//enter duration struct
			token = strtok(NULL, ":"); //allows us to read and get the '3' (for 3 min)
			r.Length.Minutes = atoi(token);//Overwrite
			token = strtok(NULL, ",");
			r.Length.Seconds = atoi(token);//atoi askii to integer, converts the string (3\0) into a int (3), //Overwrite
			//leave duration struct


			token = strtok(NULL, ",");//the comma is the delimiter
			r.PlayCount = atoi(token);//Overwrite
			token = strtok(NULL, "\n");//the comma is the delimiter
			r.Rating = atoi(token);//Overwrite

			InsertFront(pList, r);
			i++;
		}
	}
	fclose(infile);
	printf("Load Successful\n");
	return success;
}

/*************************************************************
* Function: int store_by_writing(Node *pList)
* Date Last Modified:      9:12:16
* Description:     This program writes to a file the artist, song title, duration, rating, playcount, and genre of a record.
* Colloaborator(s): Josh Mandoli
* Pre: load_by_writing must have been ran. If not, no data will be printed.
* Returns:				success
*************************************************************/
int store_by_writing(Node *pList)
{
	FILE *outfile = fopen("music.csv", "w");
	Node * pTemp = pList;
	int success = 0;


	while (pTemp != NULL)	 //while we are not at the end of the list
	{						// now we need to print a node.
		fprintf(outfile, "%s, %s, %s, %s, %d:%d, %d, %d\n", pTemp->data.Artist, pTemp->data.Album, pTemp->data.Song,
			pTemp->data.Genre, pTemp->data.Length.Minutes, pTemp->data.Length.Seconds, pTemp->data.PlayCount, pTemp->data.Rating); //print current song
		pTemp = pTemp->pNext; //advancing to the next node. 
	}

	fclose(outfile);
	success = 1;
	return success;
}

/*************************************************************
* Function: void display_all_records(Node *pList)
* Date Last Modified:      9:21:16
* Description:     This program displays all records.
* Pre: load_by_writing or insert_new_song must have been ran. If not, no data will be displayed.
* Returns:				void
*************************************************************/
void display_all_records(Node *pList)
{
	Node * pTemp = pList;
	while (pTemp != NULL)	 //while we are not at the end of the list
	{						// now we need to print a node.
		printf("%s, %s, %s, %s, %d:%d, %d, %d\n", pTemp->data.Artist, pTemp->data.Album, pTemp->data.Song,
			pTemp->data.Genre, pTemp->data.Length.Minutes, pTemp->data.Length.Seconds, pTemp->data.PlayCount, pTemp->data.Rating); //display current song
		pTemp = pTemp->pNext; //advancing to the next node. 
	}
}

/*************************************************************
* Function: void display_by_artist(Node *pList, char desired_artist[50])
* Date Last Modified:      9:21:16
* Description:     This program displays all records from a specific artist.
* Pre: load_by_writing or insert_new_song must have been ran. If not, no data will be displayed.
* Returns:				void
*************************************************************/
void display_by_artist(Node *pList, char desired_artist[50])
{
	Node * pTemp = pList;

		while (pTemp != NULL)	 //while we are not at the end of the list
		{						// now we need to print a node.
			if (strcmp(desired_artist, pTemp->data.Artist) == 0)
			{
				printf("%s, %s, %s, %s, %d:%d, %d, %d\n", pTemp->data.Artist, pTemp->data.Album, pTemp->data.Song,
					pTemp->data.Genre, pTemp->data.Length.Minutes, pTemp->data.Length.Seconds, pTemp->data.PlayCount, pTemp->data.Rating); //display current song
			}
			pTemp = pTemp->pNext; //advance
		}
}

/*************************************************************
* Function: int insert_new_song(Node **pList)
* Date Last Modified:      9:21:16
* Description:     This program inserts a new song and forces the user to fill all information pieces relative to a record.
* Pre: None
* Returns:				success
*************************************************************/
int insert_new_song(Node **pList)
{
	Node *pNew = NULL;
	Record r;
	int success = 0;
	char user_Artist[50] = { "\0" };
	char user_Album[50] = { "\0" };
	char user_Song_name[50] = { "\0" };
	char user_Genre[50] = { "\0" };
	int user_Minutes = 0;
	int user_Seconds = 0;
	int user_PlayCount = 0;
	int user_Rating = 0; 

	printf("Enter the Artist of the Song: \n");
	gets(user_Artist);
	gets(user_Artist);
	strcpy(r.Artist, user_Artist);//Overwrite
	printf("Enter the Album of the Song: \n");
	gets(user_Album);
	strcpy(r.Album, user_Album);//Overwrite
	printf("Enter the Song Name: \n");
	gets(user_Song_name);
	strcpy(r.Song, user_Song_name);//Overwrite
	printf("Enter the Genre of the Song: \n");
	gets(user_Genre);
	strcpy(r.Genre, user_Genre);//Overwrite

	printf("Enter the Length in Minutes of the Song: \n");
	scanf("%d", &user_Minutes);
	r.Length.Minutes = user_Minutes;//Overwrite
	printf("Enter the Length in Seconds of the Song: \n");
	scanf("%d", &user_Seconds);
	r.Length.Seconds = user_Seconds;//Overwrite
	printf("Enter the Playcount of the Song: \n");
	scanf("%d", &user_PlayCount);
	r.PlayCount = user_PlayCount;//Overwrite
	printf("Enter the Rating of the Song: \n");
	scanf("%d", &user_Rating);
	r.Rating = user_Rating; //Overwrite

	InsertFront(pList, r); //make and attach new node to front of list
	success = 1;
	return success;
}

/*************************************************************
* Function: int insert_new_song(Node **pList)
* Date Last Modified:      9:21:16
* Description:     This function changes the rating of a song loaded in the list by overwriting the current rating with a user rating.
* Pre: load_by_writing or insert_new_song must have been ran. If not, no data will be changed.
* Returns:				success
*************************************************************/
int rate_by_song(Node **pList, char desired_song[50])
{
	Node * pTemp = *pList;
	int user_rating = 0;
	int ratesuccess = 0;

	while (pTemp != NULL)	 //while we are not at the end of the list
	{						// now we need to print a node.
		if (strcmp(desired_song, pTemp->data.Song) == 0)
		{
			printf("What would you like to rate this song? (1-5)\n");
			scanf("%d", &user_rating); //get choice
			pTemp->data.Rating = user_rating; //Overwrite rating
			ratesuccess = 1;
			printf("Change successful.\n\n");
		}
		pTemp = pTemp->pNext;
	}

	if (ratesuccess == 0)
	{
		printf("There is no title matching '%s' in your music library.\n\n", desired_song);
	}

	return ratesuccess;
}

/*************************************************************
* Function: int insert_new_song(Node **pList)
* Date Last Modified:      9:21:16
* Description:     This function deletes a node by searching for the name of a song
* Pre: load_by_writing or insert_new_song must have been ran. If not, no data may be deleted and the program will crash.
* Returns:				success
*************************************************************/
int delete_by_song(Node **pList, char delete_song[50])
{
	Node *pCur = *pList, *pPrev = NULL;
	int success = 0;

	while ((pCur != NULL) && (strcmp(delete_song, pCur->data.Song) != 0))//compare the name found desired with the name found at pcurrent 
	{ //short cicuit is used above in case deleting at the end
	  //now we need to advance to the next node
		pPrev = pCur;
		pCur = pCur->pNext;
	}
	//Edge Cases? Deleting the first node
	if (pPrev == NULL)
	{
		//what happens if the list is empty? precondition not satisfied, program breaks, not my fault
		*pList = pCur->pNext;
		free(pCur);
		success = 1;
	}
	else//not deleting first node or didnt find the artist in list
	{
		if (pCur != NULL)//did not reach end of list, must have found searchData
		{
			//not front of list
			pPrev->pNext = pCur->pNext;
			free(pCur); //node now deleted
			success = 1;
		}
	}
	//free(pCur); //we cannot put this here, we would be trying to free the end of the list
	return success;
}

/*************************************************************
* Function: int edit_by_artist(Node **pList, char desired_artist[50])
* Date Last Modified:      9:23:16
* Description:     This function edits an entire node by searching for an artist desired by the user.
* Pre: load_by_writing or insert_new_song must have been ran. If not, no data may be edited and the program will crash.
* Returns:				success
*************************************************************/
int edit_by_artist(Node **pList, char desired_artist[50])
{
	Node * pTemp = *pList;
	int user_choice = 0;
	int editsuccess = 0;
	char user_Artist[50] = { "\0" };
	char user_Album[50] = { "\0" };
	char user_Song_name[50] = { "\0" };
	char user_Genre[50] = { "\0" };
	int user_Minutes = 0;
	int user_Seconds = 0;
	int user_PlayCount = 0;
	int user_Rating = 0;

	while (pTemp != NULL)	 //while we are not at the end of the list
	{						// now we need to print a node.
		if (strcmp(desired_artist, pTemp->data.Artist) == 0)
		{
			printf("The following record matches the artist '%s'.\nWould you like to edit this record(1) or keep looking for another? (2)\n", desired_artist);
			printf("%s, %s, %s, %s, %d:%d, %d, %d\n", pTemp->data.Artist, pTemp->data.Album, pTemp->data.Song,
				pTemp->data.Genre, pTemp->data.Length.Minutes, pTemp->data.Length.Seconds, pTemp->data.PlayCount, pTemp->data.Rating); //print the found song
			scanf("%d", &user_choice); //edit this one or keep going
			if (user_choice == 1)
			{
				printf("Enter the New Artist of this Record: \n");
				gets(user_Artist);
				gets(user_Artist);
				strcpy(pTemp->data.Artist, user_Artist); //Overwrite
				printf("Enter the New Album of this Record: \n");
				gets(user_Album);
				strcpy(pTemp->data.Album, user_Album);//Overwrite
				printf("Enter the New Song Name of this Record: \n");
				gets(user_Song_name);
				strcpy(pTemp->data.Song, user_Song_name);//Overwrite
				printf("Enter the New Genre of this Record: \n");
				gets(user_Genre);
				strcpy(pTemp->data.Genre, user_Genre);//Overwrite

				printf("Enter the New Length in Minutes of this Record: \n");
				scanf("%d", &user_Minutes);
				pTemp->data.Length.Minutes = user_Minutes;//Overwrite
				printf("Enter the New Length in Seconds of this Record: \n");
				scanf("%d", &user_Seconds);
				pTemp->data.Length.Seconds = user_Seconds;//Overwrite
				printf("The New Playcount of this Record is 0. \n");
				user_PlayCount = 0;
				pTemp->data.PlayCount = user_PlayCount;//Overwrite
				printf("Enter the New Rating of this Record: \n");
				scanf("%d", &user_Rating);
				pTemp->data.Rating = user_Rating;//Overwrite

				editsuccess = 1;
				printf("Change successful.\n\n");
				break;
			}
			else
			{
				pTemp = pTemp->pNext; //advance list
			}
		}
		else
		{
			pTemp = pTemp->pNext; //advance list
		}
	}

	if (editsuccess == 0)
	{
		printf("There is no further songs matching the artist '%s' in your music library.\n\n", desired_artist);
	}

	return editsuccess;
}

/*************************************************************
* WARNING: THIS FUNCTION DOES NOT PERFORM CORRECTLY
* Function: int sort_by_bubble(Node **pList, int sort_option)
* Date Last Modified:      9:23:16
* Description:     This function sorts the list based on the user's choice.
* Pre: load_by_writing must have been ran. If not, no data may be swapped and the program will crash.
* Returns:				success
*************************************************************/
int sort_by_bubble(Node **pList, int sort_option)
{
	Node *pCount = *pList;
	Node *pTemp1 = *pList;
	Node *pTemp2 = *pList;
	int Citerator = 1;
	int Uiterator = 0;
	int Iiterator = 1;
	int count = 0, success = 0;
	Node *pTempStore = NULL;

	if (pCount == NULL)
	{
		printf("You have no songs loaded.\n\n");
	}

	while (pCount != NULL)
	{
		pCount = pCount->pNext;
		count++;
	}

	Uiterator = count; //get size of list

	if (sort_option == 1)
	{
		for (Citerator = 0; Citerator < Uiterator; Citerator++)
		{
			for (Iiterator = 1; Iiterator < Uiterator; Iiterator++)
			{
				if (strcmp(pTemp1->data.Artist, pTemp2->pNext->data.Artist) > 0)//beginning swap
				{
					pTempStore = pTemp2->pNext; //store temp
					pTemp2->pNext = pTemp1;//swap
					pTemp1 = pTempStore;
				}

			}
		}
		success = 1;
	}
	else if (sort_option == 1)
	{
		for (Citerator = 0; Citerator < Uiterator; Citerator++)
		{
			for (Iiterator = 1; Iiterator < Uiterator; Iiterator++)
			{
				if (strcmp(pTemp1->data.Album, pTemp2->pNext->data.Album) > 0)//beginning swap
				{
					pTempStore = pTemp2->pNext; //store temp
					pTemp2->pNext = pTemp1;//swap
					pTemp1 = pTempStore;
				}

			}
		}
		success = 1;
	}
	else if (sort_option == 3)
	{
		for (Citerator = 0; Citerator < Uiterator; Citerator++)
		{
			for (Iiterator = 1; Iiterator < Uiterator; Iiterator++)
			{
				if (pTemp1->data.Rating > pTemp2->pNext->data.Rating)//beginning swap
				{
					pTempStore = pTemp2->pNext; //store temp
					pTemp2->pNext = pTemp1;//swap
					pTemp1 = pTempStore;
				}

			}
		}
		success = 1;
	}
	else if (sort_option == 4)
	{
		for (Citerator = 0; Citerator < Uiterator; Citerator++)
		{
			for (Iiterator = 1; Iiterator < Uiterator; Iiterator++)
			{
				if (pTemp1->data.PlayCount > pTemp2->pNext->data.PlayCount)//beginning swap
				{
					pTempStore = pTemp2->pNext; //store temp
					pTemp2->pNext = pTemp1;//swap
					pTemp1 = pTempStore;
				}

			}
		}
		success = 1;
	}
	else
	{
		printf("Invalid sorting choice. Please enter a number between 1-4.\n\n");
	}

	return success;
}