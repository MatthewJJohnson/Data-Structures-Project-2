#include "Header.h"


//IMPORTANT: Due to the nature of strtok, everytime the program prints the list to a file,
// an extra space will be added after each comma. This will prevent any functions that require the user
// to input a string to fail, unless the user accounts for these spaces.
//Therefore, music.csv MUST BE RESET if "STORE" or "EXIT" are ever used before a user enters a string.

//This assignment is complete and runs properly with the exception of the Sort function.
//I have attempted to write a sort function, as seen in Equations.c.
//I have provided extra comments in an attempt to gain a little bit of extra credit.
//Happy Grading :)

/*******************************************************************************
* Programmer: Matthew J Johnson
* Class: CptS 121; Lab Section 1
* Programming Assignment: PA2
* Date:   9/23/2016
* Colloaborator(s): Josh Mandoli
* Description: This program performs creates a music menu with 9 different options.
* Relevant Formulas: Refer to each function definition.
******************************************************************************/
int main(void)
{
	int option = 0;
	int exit_value = 0;
	Node *pList = NULL; //initialize

	do
	{
		option = run_menu(); //display option choices and get an option from the user
		exit_value = determine_operation(option, &pList); //enter the switch statement that runs the entire program
	} while (exit_value != 1); //while flag not triggered

	return 0;
}

//self note if i am modifying data I need a double star
//If i am walking through data, I need a single star