#ifndef HEADER_H
#define HEADER_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define LOAD 1
#define STORE 2
#define DISPLAY 3
#define INSERT 4
#define DELETE 5
#define EDIT 6
#define SORT 7
#define RATE 8
#define EXIT 9

typedef struct duration
{
	int Minutes;
	int Seconds;
}Duration;

typedef struct record
{
	char Artist[100];
	char Album[50];
	char Song[50];
	char Genre[20];
	Duration Length; //minutes and seconds are in struct duration
	int PlayCount;
	int Rating;
} Record;

typedef struct node
{
	Record data;
	struct node *pNext;
	struct node *pPrev;//doubly linked pointer
} Node;

Node * makeNode(Record newData); //allocation

void display_menu(void);
int get_option(void);
int is_valid(int option);
int run_menu(void);
int determine_operation(int option, Node**pList);
int InsertFront(Node **pList, Record newData);
int load_by_reading(Node **pList);
int store_by_writing(Node *pHead);
void display_all_records(Node *pList);
void display_by_artist(Node *pList, char desired_artist[50]);
int insert_new_song(Node **pList);
int rate_by_song(Node **pList, char desired_song[50]);
int delete_by_song(Node **pList, char delete_song[50]);
int edit_by_artist(Node **pList, char desired_artist[50]);
int sort_by_bubble(Node **pList, int sort_option);

#endif 